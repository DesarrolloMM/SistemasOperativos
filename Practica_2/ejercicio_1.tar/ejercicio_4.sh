#!/bin/bash
path=$1
fileName=$2

if [[ -d $path ]]; then
    echo "Ruta válida"
    else
    echo "ERROR: el primer argumento debe ser una ruta valida"
    exit 1
fi


if [[ -f $fileName ]]; then
    echo "Archivo existe"
    else
    echo "Archivo no existe"
fi
